# AutoClicker Pro - 增强版安卓自动点击器

功能全面的 Android 自动点击工具，基于 **AccessibilityService**（无障碍服务），**无需 Root**。

## 功能清单

| 功能 | 说明 | 状态 |
|------|------|------|
| 坐标点击 | 直接点击屏幕 (x,y) | ✅ |
| 控件文本点击 | 按文字自动找控件并点击 | ✅ |
| 控件ID点击 | 按 resourceId 精准点击 | ✅ |
| **长按** | 在指定位置长按指定时长 | ✅ |
| **滑动/拖拽** | 从 (x1,y1) 滑动到 (x2,y2) | ✅ |
| **多点序列** | 按顺序执行多个点击/滑动/长按 | ✅ |
| **录制回放** | 录下操作→保存→无限回放 | ✅ |
| **随机延迟** | 每次间隔随机波动，防检测 | ✅ |
| **条件逻辑** | 等待某文字出现/某文字出现时停止 | ✅ |
| **图片定位** | 截图找图，点击匹配位置 | ✅ |
| **悬浮控制窗** | 随时悬浮，一键启停录制 | ✅ |
| **配置管理** | 多套方案保存/加载/切换 | ✅ |
| 自定义间隔 | 毫秒级精确控制 | ✅ |
| 无限/指定循环 | -1 无限，N 次停止 | ✅ |
| 无登录/无激活/无限制 | 完全离线，开源免费 | ✅ |

## 项目结构

```
android-auto-clicker/
├── app/src/main/
│   ├── AndroidManifest.xml
│   ├── java/com/example/autoclicker/
│   │   ├── service/
│   │   │   ├── ClickAccessibilityService.java  # 核心引擎（全部功能）
│   │   │   ├── GestureRecorder.java            # 录制回放引擎
│   │   │   ├── ImageMatcher.java               # 图片定位匹配（NCC算法）
│   │   │   ├── FloatingController.java         # 悬浮控制窗
│   │   │   └── ConfigManager.java              # 配置存储管理
│   │   └── ui/
│   │       └── MainActivity.java               # 增强版主界面
│   └── res/
│       ├── layout/activity_main.xml            # Tab布局（基础/配置）
│       ├── values/strings.xml
│       ├── values/styles.xml
│       ├── values/ids.xml
│       ├── xml/accessibility_service_config.xml
│       └── drawable/ic_launcher.xml
├── app/build.gradle
├── build.gradle
└── settings.gradle
```

## 编译

```bash
cd android-auto-clicker
./gradlew assembleDebug
# 输出: app/build/outputs/apk/debug/app-debug.apk
```

## 使用说明

### 基础操作
1. 安装 APK，开启「无障碍服务」
2. 选择模式（坐标/文本/ID/长按/滑动）
3. 填入参数，点击「➕ 添加到任务列表」
4. 设置间隔、随机延迟、循环次数
5. 点击「▶ 开始」

### 录制回放
1. 点击「🔴 录制」
2. 在目标 App 上手动操作
3. 点击「⏹ 停录」
4. 录制自动保存为 JSON，下次可回放

### 条件逻辑
- **等待文本**：填入"加载中..."，会等待该文字出现后才开始
- **停止文本**：填入"已完成"，出现该文字时自动停止

### 悬浮窗
开启后可在任何界面快速启停、录制，无需切回 App

### 配置管理
在「配置」Tab 保存多套方案，一键切换不同场景

## 技术原理

### 核心手势派发
```java
// 点击
Path path = new Path();
path.moveTo(x, y);
dispatchGesture(new GestureDescription.Builder()
    .addStroke(new StrokeDescription(path, 0, 100))
    .build(), null, null);

// 滑动
path.moveTo(x1, y1);
path.lineTo(x2, y2);
dispatchGesture(..., duration);
```

### 控件查找
```java
AccessibilityNodeInfo root = getRootInActiveWindow();
// 递归遍历控件树，匹配 text / contentDescription / resourceId
```

### 录制格式 (JSON)
```json
[
  {"delay":1000, "type":0, "value":"500,300"},
  {"delay":2000, "type":1, "value":"签到按钮"},
  {"delay":500,  "type":4, "value":"100,500,100,200,300"}
]
```

### 图片匹配算法
- **NCC 归一化互相关**（Normalized Cross Correlation）
- 阈值默认 0.85，可调整
- 需要 MediaProjection 截屏权限配合使用

## 权限

| 权限 | 用途 |
|------|------|
| 无障碍服务 | 读取控件树 + 模拟手势 |
| 悬浮窗 | 悬浮控制按钮 |

## License

MIT - 随便用，随便改
