# Add project specific ProGuard rules here.
-keep class com.example.autoclicker.** { *; }
-keepclassmembers class com.example.autoclicker.service.ClickAccessibilityService { *; }
