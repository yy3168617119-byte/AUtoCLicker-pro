package com.example.autoclicker.service;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

/**
 * 配置存储管理
 * 
 * 功能：
 * - 保存/加载多套配置方案
 * - 配置包含：模式、坐标、间隔、循环、随机延迟、条件等
 * - 存储在 SharedPreferences 中
 */
public class ConfigManager {

    private static final String TAG = "ConfigManager";
    private static final String PREF_NAME = "AutoClickerConfigs";
    private static final String KEY_CONFIG_LIST = "config_list";

    private SharedPreferences prefs;

    public ConfigManager(Context context) {
        prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
    }

    /**
     * 保存一套配置
     */
    public void saveConfig(String name, Config config) {
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString("config_" + name, config.toJson());
        editor.apply();

        // 更新列表
        List<String> list = getConfigList();
        if (!list.contains(name)) {
            list.add(name);
            editor.putString(KEY_CONFIG_LIST, String.join(",", list));
        }
        editor.apply();

        Log.d(TAG, "保存配置: " + name);
    }

    /**
     * 加载一套配置
     */
    public Config loadConfig(String name) {
        String json = prefs.getString("config_" + name, null);
        if (json == null) return null;
        return Config.fromJson(json);
    }

    /**
     * 删除配置
     */
    public void deleteConfig(String name) {
        SharedPreferences.Editor editor = prefs.edit();
        editor.remove("config_" + name);
        editor.apply();

        List<String> list = getConfigList();
        list.remove(name);
        editor.putString(KEY_CONFIG_LIST, String.join(",", list));
        editor.apply();

        Log.d(TAG, "删除配置: " + name);
    }

    /**
     * 获取所有配置名称
     */
    public List<String> getConfigList() {
        String raw = prefs.getString(KEY_CONFIG_LIST, "");
        if (raw.isEmpty()) return new ArrayList<>();
        List<String> list = new ArrayList<>();
        for (String item : raw.split(",")) {
            if (!item.isEmpty()) list.add(item.trim());
        }
        return list;
    }

    /**
     * 配置数据结构
     */
    public static class Config {
        public int mode = 0;           // 0=坐标, 1=文本, 2=ID
        public int x = 0, y = 0;       // 坐标
        public String text = "";       // 文本/ID
        public int interval = 1000;    // 间隔
        public int randomDelay = 0;    // 随机延迟
        public int loopCount = -1;     // 循环
        public String waitText = "";   // 等待文本
        public String stopText = "";   // 停止文本

        // 多点序列（JSON 数组字符串）
        public String sequence = "";

        public String toJson() {
            return String.format(
                "{\"mode\":%d,\"x\":%d,\"y\":%d,\"text\":\"%s\",\"interval\":%d," +
                "\"randomDelay\":%d,\"loopCount\":%d,\"waitText\":\"%s\"," +
                "\"stopText\":\"%s\",\"sequence\":\"%s\"}",
                mode, x, y, escape(text), interval, randomDelay,
                loopCount, escape(waitText), escape(stopText), escape(sequence)
            );
        }

        public static Config fromJson(String json) {
            Config c = new Config();
            try {
                c.mode = extractInt(json, "mode");
                c.x = extractInt(json, "x");
                c.y = extractInt(json, "y");
                c.text = extractString(json, "text");
                c.interval = extractInt(json, "interval");
                c.randomDelay = extractInt(json, "randomDelay");
                c.loopCount = extractInt(json, "loopCount");
                c.waitText = extractString(json, "waitText");
                c.stopText = extractString(json, "stopText");
                c.sequence = extractString(json, "sequence");
            } catch (Exception e) {
                Log.e(TAG, "解析配置失败: " + e.getMessage());
            }
            return c;
        }

        private static int extractInt(String json, String key) {
            try {
                int idx = json.indexOf("\"" + key + "\":");
                if (idx < 0) return 0;
                int start = idx + key.length() + 3;
                int end = json.indexOf(",", start);
                if (end < 0) end = json.indexOf("}", start);
                return Integer.parseInt(json.substring(start, end).trim());
            } catch (Exception e) { return 0; }
        }

        private static String extractString(String json, String key) {
            try {
                int idx = json.indexOf("\"" + key + "\":\"");
                if (idx < 0) return "";
                int start = idx + key.length() + 4;
                int end = json.indexOf("\"", start);
                return json.substring(start, end).replace("\\\"", "\"");
            } catch (Exception e) { return ""; }
        }

        private String escape(String s) {
            if (s == null) return "";
            return s.replace("\"", "\\\"");
        }
    }
}
