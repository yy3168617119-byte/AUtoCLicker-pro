package com.example.autoclicker.service;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.PixelFormat;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;

/**
 * 悬浮控制窗
 * 
 * 功能：
 * - 始终悬浮在屏幕最上层
 * - 拖动移动位置
 * - 点击展开：开始/停止/录制/回放
 * - 显示当前状态
 */
@SuppressLint("ClickableViewAccessibility")
public class FloatingController {

    private static final String TAG = "FloatingController";

    private Context context;
    private WindowManager windowManager;
    private WindowManager.LayoutParams params;
    private LinearLayout floatView;
    private boolean visible = false;

    private floatViewListener listener;
    private Handler mainHandler = new Handler(Looper.getMainLooper());

    // 拖拽相关
    private int initialX, initialY;
    private float initialTouchX, initialTouchY;

    public interface floatViewListener {
        void onStart();
        void onStop();
        void onRecord();
        void onReplay();
    }

    public FloatingController(Context context, floatViewListener listener) {
        this.context = context;
        this.listener = listener;
        this.windowManager = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
    }

    /**
     * 显示悬浮窗
     */
    public void show() {
        if (visible) return;

        params = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        );
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = 100;
        params.y = 300;

        createFloatView();
        windowManager.addView(floatView, params);
        visible = true;
        Log.d(TAG, "悬浮窗已显示");
    }

    /**
     * 隐藏悬浮窗
     */
    public void hide() {
        if (!visible) return;
        windowManager.removeView(floatView);
        visible = false;
        Log.d(TAG, "悬浮窗已隐藏");
    }

    /**
     * 更新状态显示
     */
    public void updateStatus(String status) {
        if (floatView != null) {
            Button btnStatus = floatView.findViewById(R.id.btnFloatStatus);
            if (btnStatus != null) {
                btnStatus.setText(status);
            }
        }
    }

    /**
     * 创建悬浮视图
     */
    private void createFloatView() {
        floatView = new LinearLayout(context);
        floatView.setOrientation(LinearLayout.VERTICAL);
        floatView.setBackgroundColor(0xCC000000);
        floatView.setPadding(8, 8, 8, 8);

        // 状态按钮（也可拖动）
        Button btnStatus = new Button(context);
        btnStatus.setText("⏸ 就绪");
        btnStatus.setId(R.id.btnFloatStatus);
        btnStatus.setBackgroundColor(0xFF4CAF50);
        btnStatus.setTextColor(0xFFFFFFFF);
        btnStatus.setPadding(16, 8, 16, 8);

        LinearLayout.LayoutParams statusParams = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        );
        statusParams.setMargins(0, 0, 0, 4);
        floatView.addView(btnStatus, statusParams);

        // 开始
        Button btnStart = new Button(context);
        btnStart.setText("▶ 开始");
        btnStart.setBackgroundColor(0xFF2196F3);
        btnStart.setTextColor(0xFFFFFFFF);
        btnStart.setPadding(12, 6, 12, 6);
        btnStart.setOnClickListener(v -> listener.onStart());

        LinearLayout.LayoutParams btnParams = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        );
        btnParams.setMargins(0, 0, 0, 4);
        floatView.addView(btnStart, btnParams);

        // 停止
        Button btnStop = new Button(context);
        btnStop.setText("⏹ 停止");
        btnStop.setBackgroundColor(0xFFF44336);
        btnStop.setTextColor(0xFFFFFFFF);
        btnStop.setPadding(12, 6, 12, 6);
        btnStop.setOnClickListener(v -> listener.onStop());
        floatView.addView(btnStop, btnParams.clone());

        // 录制
        Button btnRecord = new Button(context);
        btnRecord.setText("🔴 录制");
        btnRecord.setBackgroundColor(0xFFFF5722);
        btnRecord.setTextColor(0xFFFFFFFF);
        btnRecord.setPadding(12, 6, 12, 6);
        btnRecord.setOnClickListener(v -> listener.onRecord());
        floatView.addView(btnRecord, btnParams.clone());

        // 回放
        Button btnReplay = new Button(context);
        btnReplay.setText("▶️ 回放");
        btnReplay.setBackgroundColor(0xFFFF9800);
        btnReplay.setTextColor(0xFFFFFFFF);
        btnReplay.setPadding(12, 6, 12, 6);
        btnReplay.setOnClickListener(v -> listener.onReplay());
        floatView.addView(btnReplay, btnParams.clone());

        // 拖拽支持
        btnStatus.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        initialX = params.x;
                        initialY = params.y;
                        initialTouchX = event.getRawX();
                        initialTouchY = event.getRawY();
                        return true;

                    case MotionEvent.ACTION_MOVE:
                        params.x = initialX + (int) (event.getRawX() - initialTouchX);
                        params.y = initialY + (int) (event.getRawY() - initialTouchY);
                        windowManager.updateViewLayout(floatView, params);
                        return true;
                }
                return false;
            }
        });
    }
}
