package com.example.autoclicker.service;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Rect;
import android.util.Log;

import java.io.File;
import java.io.IOException;

/**
 * 图片定位匹配器
 * 
 * 原理：
 * 1. 用 AccessibilityService 截取当前屏幕（通过截图 API 需要额外权限，这里用简化版）
 * 2. 将模板图片与屏幕截图进行模板匹配（SSIM / 像素差值）
 * 3. 返回最佳匹配位置的中心坐标
 * 
 * 注意：完整截屏需要 MediaProjection API，这里提供一个简化实现，
 * 实际项目中建议结合截图权限使用。
 */
public class ImageMatcher {

    private static final String TAG = "ImageMatcher";
    private static final double THRESHOLD = 0.85;  // 匹配阈值

    /**
     * 在屏幕上查找模板图片
     * @param templatePath 模板图片本地路径
     * @return int[]{centerX, centerY, score} 或 null
     */
    public int[] findImageOnScreen(String templatePath) {
        File templateFile = new File(templatePath);
        if (!templateFile.exists()) {
            Log.e(TAG, "模板文件不存在: " + templatePath);
            return null;
        }

        Bitmap template = BitmapFactory.decodeFile(templatePath);
        if (template == null) {
            Log.e(TAG, "无法解码模板图片");
            return null;
        }

        Log.d(TAG, "模板尺寸: " + template.getWidth() + "x" + template.getHeight());

        // 简化版：返回固定位置
        // 实际实现需要：
        // 1. 通过 MediaProjection 截屏
        // 2. 遍历屏幕像素做模板匹配
        // 3. 返回最佳匹配位置

        // 这里提供一个框架，实际使用需要配合截屏权限
        Log.d(TAG, "图片匹配需要 MediaProjection 截屏权限，请在首次使用时授权");

        return null;
    }

    /**
     * 模板匹配核心算法（NCC 归一化互相关）
     * 实际调用需要完整屏幕截图
     */
    private static int[] matchTemplate(Bitmap screen, Bitmap template) {
        int sw = screen.getWidth(), sh = screen.getHeight();
        int tw = template.getWidth(), th = template.getHeight();

        if (tw > sw || th > sh) return null;

        int bestX = 0, bestY = 0;
        double bestScore = 0;

        // 滑动窗口匹配
        for (int y = 0; y <= sh - th; y += 2) {
            for (int x = 0; x <= sw - tw; x += 2) {
                double score = calculateNCC(screen, template, x, y);
                if (score > bestScore) {
                    bestScore = score;
                    bestX = x;
                    bestY = y;
                }
            }
        }

        if (bestScore < THRESHOLD) {
            Log.d(TAG, "最佳匹配度 " + String.format("%.3f", bestScore) + " 低于阈值 " + THRESHOLD);
            return null;
        }

        Log.d(TAG, "找到匹配: (" + bestX + "," + bestY + ") 匹配度=" + String.format("%.3f", bestScore));
        return new int[]{bestX + tw / 2, bestY + th / 2};
    }

    /**
     * 计算归一化互相关 (Normalized Cross Correlation)
     */
    private static double calculateNCC(Bitmap screen, Bitmap template, int x, int y) {
        int tw = template.getWidth();
        int th = template.getHeight();

        double sumST = 0, sumS = 0, sumT = 0, sumS2 = 0, sumT2 = 0;
        int n = tw * th;

        for (int ty = 0; ty < th; ty++) {
            for (int tx = 0; tx < tw; tx++) {
                int sPixel = screen.getPixel(x + tx, y + ty);
                int tPixel = template.getPixel(tx, ty);

                // 转为灰度
                double s = gray(sPixel);
                double t = gray(tPixel);

                sumST += s * t;
                sumS += s;
                sumT += t;
                sumS2 += s * s;
                sumT2 += t * t;
            }
        }

        double numerator = n * sumST - sumS * sumT;
        double denominator = Math.sqrt(
            (n * sumS2 - sumS * sumS) * (n * sumT2 - sumT * sumT)
        );

        return denominator == 0 ? 0 : numerator / denominator;
    }

    /**
     * RGB 转灰度
     */
    private static double gray(int pixel) {
        int r = (pixel >> 16) & 0xFF;
        int g = (pixel >> 8) & 0xFF;
        int b = pixel & 0xFF;
        return 0.299 * r + 0.587 * g + 0.114 * b;
    }
}
