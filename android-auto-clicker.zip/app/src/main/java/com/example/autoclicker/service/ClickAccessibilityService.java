package com.example.autoclicker.service;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.graphics.Rect;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import com.example.autoclicker.service.GestureRecorder.GestureEvent;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * 增强版自动点击无障碍服务
 * 
 * 全部功能：
 * 1. 坐标点击 / 控件文本点击 / 控件ID点击
 * 2. 多点手势序列（点击+滑动+长按）
 * 3. 随机延迟（防检测）
 * 4. 条件逻辑（出现某文字才点击 / 控件消失时停止）
 * 5. 录制回放引擎（通过 GestureRecorder）
 * 6. 图片定位点击（通过 ImageMatcher）
 */
public class ClickAccessibilityService extends AccessibilityService {

    private static final String TAG = "AutoClicker";

    // ==================== 单例 & 状态 ====================
    public static ClickAccessibilityService instance = null;
    private static final AtomicBoolean isRunning = new AtomicBoolean(false);

    // ==================== 运行控制 ====================
    private Handler mainHandler = new Handler(Looper.getMainLooper());
    private Runnable clickRunnable;
    private AtomicInteger currentLoop = new AtomicInteger(0);
    private AtomicInteger currentTaskIndex = new AtomicInteger(0);

    // ==================== 配置参数 ====================
    // 任务列表
    private List<ClickTask> tasks = new ArrayList<>();
    private int intervalMs = 1000;          // 两次点击间隔
    private int randomDelayMs = 0;          // 随机延迟范围（±X ms）
    private int loopCount = -1;             // 循环次数 -1=无限
    private boolean recordMode = false;     // 录制模式
    private String recordPath = null;       // 录制保存路径
    private String replayPath = null;       // 回放加载路径
    private String matchImagePath = null;   // 图片定位：模板图片路径
    private int matchImageX = -1;           // 图片匹配后点击偏移 X
    private int matchImageY = -1;           // 图片匹配后点击偏移 Y
    private String waitText = null;         // 条件：等待出现此文本才继续
    private String stopText = null;         // 条件：出现此文本时停止
    private boolean waitTextInvert = false; // 条件反转：文本消失时停止

    // 录制器 & 图片匹配器
    private GestureRecorder recorder = null;
    private ImageMatcher imageMatcher = null;

    // 随机数
    private Random random = new Random();

    @Override
    public void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
        Log.d(TAG, "无障碍服务已连接");
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        // 条件监听：检查 stopText / waitText
        if (stopText != null && !stopText.isEmpty()) {
            CharSequence text = event.getText() != null && !event.getText().isEmpty()
                    ? event.getText().get(0) : null;
            if (text != null && text.toString().contains(stopText)) {
                Log.d(TAG, "检测到停止文本: " + stopText);
                stopClicking();
            }
        }
    }

    @Override
    public void onInterrupt() {
        Log.d(TAG, "无障碍服务中断");
    }

    @Override
    public boolean onUnbind(android.content.Intent intent) {
        stopClicking();
        instance = null;
        return super.onUnbind(intent);
    }

    // ==================== 对外 API：基础配置 ====================

    public static boolean isServiceAvailable() { return instance != null; }
    public static boolean isRunning() { return isRunning.get(); }

    public void clearTasks() {
        tasks.clear();
    }

    public void setInterval(int ms) { this.intervalMs = ms; }
    public void setRandomDelay(int ms) { this.randomDelayMs = ms; }
    public void setLoopCount(int count) { this.loopCount = count; }

    // ==================== 对外 API：任务添加 ====================

    /** 添加坐标点击任务 */
    public void addClickByXY(int x, int y) {
        tasks.add(new ClickTask(ClickTask.TYPE_CLICK, x + "," + y));
    }

    /** 添加控件文本点击任务 */
    public void addClickByText(String text) {
        tasks.add(new ClickTask(ClickTask.TYPE_TEXT, text));
    }

    /** 添加控件ID点击任务 */
    public void addClickById(String resId) {
        tasks.add(new ClickTask(ClickTask.TYPE_ID, resId));
    }

    /** 添加长按任务 (x,y, 持续时间ms) */
    public void addLongPress(int x, int y, int durationMs) {
        tasks.add(new ClickTask(ClickTask.TYPE_LONG_PRESS, x + "," + y + "," + durationMs));
    }

    /** 添加滑动手势 (x1,y1 → x2,y2, 持续时间ms) */
    public void addSwipe(int x1, int y1, int x2, int y2, int durationMs) {
        tasks.add(new ClickTask(ClickTask.TYPE_SWIPE, x1 + "," + y1 + "," + x2 + "," + y2 + "," + durationMs));
    }

    // ==================== 对外 API：录制 & 回放 ====================

    /** 开始录制手势到文件 */
    public void startRecording(String savePath) {
        if (recorder == null) recorder = new GestureRecorder();
        recorder.startRecording(savePath);
        recordMode = true;
        recordPath = savePath;
        Log.d(TAG, "开始录制 → " + savePath);
    }

    /** 停止录制 */
    public void stopRecording() {
        if (recorder != null) {
            recorder.stopRecording();
        }
        recordMode = false;
        Log.d(TAG, "录制已停止");
    }

    /** 加载并回放录制文件 */
    public void loadAndReplay(String filePath) {
        if (recorder == null) recorder = new GestureRecorder();
        List<GestureEvent> events = recorder.loadEvents(filePath);
        if (events != null && !events.isEmpty()) {
            replayPath = filePath;
            tasks.clear();
            for (GestureEvent e : events) {
                ClickTask t = e.toClickTask();
                if (t != null) tasks.add(t);
            }
            Log.d(TAG, "已加载 " + tasks.size() + 条回放任务 from " + filePath);
        }
    }

    // ==================== 对外 API：图片定位 ====================

    /** 设置图片定位：找到 matchImagePath 后点击相对偏移位置 */
    public void setImageMatch(String imagePath, int offsetX, int offsetY) {
        this.matchImagePath = imagePath;
        this.matchImageX = offsetX;
        this.matchImageY = offsetY;
    }

    // ==================== 对外 API：条件逻辑 ====================

    /** 等待某文本出现后才执行 */
    public void setWaitText(String text) {
        this.waitText = text;
    }

    /** 出现某文本时停止 */
    public void setStopText(String text) {
        this.stopText = text;
    }

    /** 文本消失时停止 */
    public void setWaitTextDisappear(boolean invert) {
        this.waitTextInvert = invert;
    }

    // ==================== 核心引擎：启停 ====================

    public void startClicking() {
        if (isRunning.get()) {
            Log.d(TAG, "已在运行中");
            return;
        }

        if (tasks.isEmpty()) {
            Log.e(TAG, "没有点击任务");
            return;
        }

        // 条件等待：waitText
        if (waitText != null && !waitText.isEmpty()) {
            if (!waitForText(waitText, waitTextInvert ? 30000 : 60000)) {
                Log.d(TAG, "等待条件超时，不执行");
                return;
            }
        }

        isRunning.set(true);
        currentLoop.set(0);
        currentTaskIndex.set(0);

        Log.d(TAG, String.format("开始: %d任务, 间隔%dms, 随机±%dms, 循环=%s",
                tasks.size(), intervalMs, randomDelayMs, loopCount == -1 ? "无限" : String.valueOf(loopCount)));

        clickRunnable = new Runnable() {
            @Override
            public void run() {
                if (!isRunning.get()) return;

                // 循环次数检查
                if (loopCount > 0 && currentLoop.get() >= loopCount) {
                    Log.d(TAG, "达到循环上限 " + loopCount);
                    stopClicking();
                    return;
                }

                // 一轮完成，重置
                if (currentTaskIndex.get() >= tasks.size()) {
                    currentTaskIndex.set(0);
                    currentLoop.incrementAndGet();
                    Log.d(TAG, "完成第 " + currentLoop.get() + " 轮");
                }

                ClickTask task = tasks.get(currentTaskIndex.get());
                boolean success = executeTask(task);

                // 录制
                if (recordMode && recorder != null) {
                    recorder.recordTask(task, success);
                }

                currentTaskIndex.incrementAndGet();

                if (isRunning.get()) {
                    int delay = intervalMs;
                    if (randomDelayMs > 0) {
                        delay += random.nextInt(randomDelayMs * 2 + 1) - randomDelayMs;
                        if (delay < 50) delay = 50;
                    }
                    mainHandler.postDelayed(this, delay);
                }
            }
        };

        mainHandler.post(clickRunnable);
    }

    public void stopClicking() {
        isRunning.set(false);
        if (clickRunnable != null) {
            mainHandler.removeCallbacks(clickRunnable);
        }
        if (recordMode && recorder != null) {
            recorder.stopRecording();
            recordMode = false;
        }
        Log.d(TAG, "已停止");
    }

    // ==================== 内部实现：条件等待 ====================

    private boolean waitForText(String text, long timeoutMs) {
        long start = System.currentTimeMillis();
        while (System.currentTimeMillis() - start < timeoutMs) {
            AccessibilityNodeInfo root = getRootInActiveWindow();
            if (root != null) {
                if (findNode(root, "text", text) != null) {
                    Log.d(TAG, "找到等待文本: " + text);
                    root.recycle();
                    return true;
                }
                root.recycle();
            }
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                break;
            }
        }
        Log.d(TAG, "等待文本超时: " + text);
        return false;
    }

    // ==================== 内部实现：任务执行 ====================

    private boolean executeTask(ClickTask task) {
        try {
            switch (task.type) {
                case ClickTask.TYPE_CLICK:
                    return clickByCoordinate(task.value);
                case ClickTask.TYPE_TEXT:
                    return clickByNode("text", task.value);
                case ClickTask.TYPE_ID:
                    return clickByNode("id", task.value);
                case ClickTask.TYPE_LONG_PRESS:
                    return longPress(task.value);
                case ClickTask.TYPE_SWIPE:
                    return swipe(task.value);
                case ClickTask.TYPE_IMAGE:
                    return clickByImage(task.value);
                default:
                    return false;
            }
        } catch (Exception e) {
            Log.e(TAG, "执行失败: " + e.getMessage());
            return false;
        }
    }

    private boolean clickByCoordinate(String xy) {
        String[] parts = xy.split(",");
        if (parts.length != 2) return false;
        int x = Integer.parseInt(parts[0].trim());
        int y = Integer.parseInt(parts[1].trim());
        return performGesture(x, y, 100);
    }

    private boolean clickByNode(String attr, String value) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return false;

        AccessibilityNodeInfo target = findNode(root, attr, value);
        if (target == null) {
            Log.d(TAG, "未找到控件: " + attr + "=" + value);
            return false;
        }

        Rect rect = new Rect();
        target.getBoundsInScreen(rect);
        target.recycle();

        // 添加一点随机偏移使点击更自然
        int centerX = rect.centerX() + random.nextInt(10) - 5;
        int centerY = rect.centerY() + random.nextInt(10) - 5;

        Log.d(TAG, "点击控件中心: (" + centerX + "," + centerY + ")");
        return performGesture(centerX, centerY, 100);
    }

    private boolean longPress(String value) {
        String[] parts = value.split(",");
        if (parts.length != 3) return false;
        int x = Integer.parseInt(parts[0].trim());
        int y = Integer.parseInt(parts[1].trim());
        int duration = Integer.parseInt(parts[2].trim());
        return performGesture(x, y, duration);
    }

    private boolean swipe(String value) {
        String[] parts = value.split(",");
        if (parts.length != 5) return false;
        int x1 = Integer.parseInt(parts[0].trim());
        int y1 = Integer.parseInt(parts[1].trim());
        int x2 = Integer.parseInt(parts[2].trim());
        int y2 = Integer.parseInt(parts[3].trim());
        int duration = Integer.parseInt(parts[4].trim());

        Path path = new Path();
        path.moveTo(x1, y1);
        path.lineTo(x2, y2);

        GestureDescription.Builder builder = new GestureDescription.Builder()
            .addStroke(new GestureDescription.StrokeDescription(path, 0, duration));

        return dispatchGesture(builder.build(), null, null);
    }

    private boolean clickByImage(String value) {
        // 图片定位点击
        if (matchImagePath == null) return false;
        if (imageMatcher == null) imageMatcher = new ImageMatcher();

        int[] result = imageMatcher.findImageOnScreen(matchImagePath);
        if (result == null) {
            Log.d(TAG, "未找到匹配图片");
            return false;
        }

        int centerX = result[0] + matchImageX;
        int centerY = result[1] + matchImageY;

        Log.d(TAG, "图片定位点击: (" + centerX + "," + centerY + ")");
        return performGesture(centerX, centerY, 100);
    }

    private boolean performGesture(int x, int y, int durationMs) {
        Path path = new Path();
        path.moveTo(x, y);

        GestureDescription.Builder builder = new GestureDescription.Builder()
            .addStroke(new GestureDescription.StrokeDescription(path, 0, durationMs));

        return dispatchGesture(builder.build(), null, null);
    }

    // ==================== 内部实现：控件查找 ====================

    private AccessibilityNodeInfo findNode(AccessibilityNodeInfo node, String attr, String value) {
        // 检查当前节点
        boolean match = false;
        switch (attr) {
            case "text":
                CharSequence text = node.getText();
                if (text != null && text.toString().contains(value)) match = true;
                // 也检查 contentDescription
                if (!match) {
                    CharSequence desc = node.getContentDescription();
                    if (desc != null && desc.toString().contains(value)) match = true;
                }
                break;
            case "id":
                String resId = node.getViewIdResourceName();
                if (resId != null && resId.contains(value)) match = true;
                break;
        }

        if (match) return node;

        // 递归子节点
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                AccessibilityNodeInfo result = findNode(child, attr, value);
                if (result != null) return result;
            }
        }
        return null;
    }

    // ==================== 任务数据结构 ====================

    public static class ClickTask {
        // 类型常量
        public static final int TYPE_CLICK = 0;
        public static final int TYPE_TEXT = 1;
        public static final int TYPE_ID = 2;
        public static final int TYPE_LONG_PRESS = 3;
        public static final int TYPE_SWIPE = 4;
        public static final int TYPE_IMAGE = 5;

        int type;
        String value;
        long timestamp;  // 录制时的时间戳

        public ClickTask(int type, String value) {
            this.type = type;
            this.value = value;
            this.timestamp = System.currentTimeMillis();
        }

        public String toJson() {
            return String.format("{\"type\":%d,\"value\":\"%s\",\"ts\":%d}", type, value, timestamp);
        }

        public static ClickTask fromJson(String json) {
            // 简单解析
            try {
                int typeIdx = json.indexOf("\"type\":");
                int typeStart = typeIdx + 7;
                int typeEnd = json.indexOf(",", typeStart);
                int type = Integer.parseInt(json.substring(typeStart, typeEnd));

                int valStart = json.indexOf("\"value\":\"") + 9;
                int valEnd = json.indexOf("\"", valStart);
                String value = json.substring(valStart, valEnd);

                return new ClickTask(type, value);
            } catch (Exception e) {
                return null;
            }
        }
    }
}
