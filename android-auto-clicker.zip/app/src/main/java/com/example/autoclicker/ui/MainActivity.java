package com.example.autoclicker.ui;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.view.View;
import android.widget.*;

import com.example.autoclicker.R;
import com.example.autoclicker.service.ClickAccessibilityService;
import com.example.autoclicker.service.ConfigManager;
import com.example.autoclicker.service.FloatingController;
import com.example.autoclicker.service.ClickAccessibilityService.ClickTask;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * 增强版主界面 - 支持全部功能
 */
public class MainActivity extends Activity implements FloatingController.floatViewListener {

    // ========== UI 组件 ==========
    private TabHost tabHost;
    private EditText edtX, edtY, edtText, edtInterval, edtLoopCount, edtRandomDelay;
    private EditText edtLongPressDuration, edtSwipeX1, edtSwipeY1, edtSwipeX2, edtSwipeY2, edtSwipeDuration;
    private EditText edtWaitText, edtStopText;
    private EditText edtImageMatchPath, edtImageOffsetX, edtImageOffsetY;
    private RadioGroup rgMode;
    private Button btnStart, btnStop, btnAddTask, btnRecord, btnStopRecord;
    private Switch swService, swFloating;
    private Spinner spSavedConfig;
    private Button btnSaveConfig, btnLoadConfig, btnDeleteConfig;
    private ListView lvTaskList;
    private ArrayAdapter<String> taskAdapter;
    private List<String> taskDisplayList = new java.util.ArrayList<>();

    // ========== 业务对象 ==========
    private ConfigManager configManager;
    private FloatingController floatingController;
    private List<ClickTask> userTasks = new java.util.ArrayList<>();

    // 录制状态
    private boolean recording = false;
    private String currentRecordPath;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        configManager = new ConfigManager(this);
        floatingController = new FloatingController(this, this);

        bindViews();
        loadSavedConfigs();
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateButtons();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        floatingController.hide();
    }

    // ==================== 初始化 ====================

    private void bindViews() {
        // TabHost 初始化
        tabHost = findViewById(android.R.id.tabhost);
        tabHost.setup();
        tabHost.addTab(tabHost.newTabSpec("basic").setIndicator("基础").setContent(R.id.tabBasic));
        tabHost.addTab(tabHost.newTabSpec("config").setIndicator("配置").setContent(R.id.tabConfig));

        // 基础
        edtX = findViewById(R.id.edtX);
        edtY = findViewById(R.id.edtY);
        edtText = findViewById(R.id.edtText);
        edtInterval = findViewById(R.id.edtInterval);
        edtLoopCount = findViewById(R.id.edtLoopCount);
        edtRandomDelay = findViewById(R.id.edtRandomDelay);
        rgMode = findViewById(R.id.rgMode);
        swService = findViewById(R.id.swService);
        swFloating = findViewById(R.id.swFloating);

        // 长按
        edtLongPressDuration = findViewById(R.id.edtLongPressDuration);
        // 滑动
        edtSwipeX1 = findViewById(R.id.edtSwipeX1);
        edtSwipeY1 = findViewById(R.id.edtSwipeY1);
        edtSwipeX2 = findViewById(R.id.edtSwipeX2);
        edtSwipeY2 = findViewById(R.id.edtSwipeY2);
        edtSwipeDuration = findViewById(R.id.edtSwipeDuration);
        // 条件
        edtWaitText = findViewById(R.id.edtWaitText);
        edtStopText = findViewById(R.id.edtStopText);
        // 图片
        edtImageMatchPath = findViewById(R.id.edtImageMatchPath);
        edtImageOffsetX = findViewById(R.id.edtImageOffsetX);
        edtImageOffsetY = findViewById(R.id.edtImageOffsetY);

        // 按钮
        btnStart = findViewById(R.id.btnStart);
        btnStop = findViewById(R.id.btnStop);
        btnAddTask = findViewById(R.id.btnAddTask);
        btnRecord = findViewById(R.id.btnRecord);
        btnStopRecord = findViewById(R.id.btnStopRecord);

        // 配置管理
        spSavedConfig = findViewById(R.id.spSavedConfig);
        btnSaveConfig = findViewById(R.id.btnSaveConfig);
        btnLoadConfig = findViewById(R.id.btnLoadConfig);
        btnDeleteConfig = findViewById(R.id.btnDeleteConfig);

        // 任务列表
        lvTaskList = findViewById(R.id.lvTaskList);
        taskAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, taskDisplayList);
        lvTaskList.setAdapter(taskAdapter);

        // 长按删除任务
        lvTaskList.setOnItemLongClickListener((parent, view, position, id) -> {
            if (position < userTasks.size()) {
                userTasks.remove(position);
                taskDisplayList.remove(position);
                taskAdapter.notifyDataSetChanged();
                Toast.makeText(this, "已删除", Toast.LENGTH_SHORT).show();
                return true;
            }
            return false;
        });

        // 开关
        swService.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                Intent intent = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
                startActivity(intent);
                Toast.makeText(this, "请在无障碍服务中找到「AutoClicker」并开启", Toast.LENGTH_LONG).show();
            } else {
                if (ClickAccessibilityService.isRunning()) {
                    ClickAccessibilityService.instance.stopClicking();
                    updateButtons();
                }
            }
        });

        swFloating.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                floatingController.show();
            } else {
                floatingController.hide();
            }
        });

        // 按钮
        btnAddTask.setOnClickListener(v -> addCurrentTask());
        btnStart.setOnClickListener(v -> startClicking());
        btnStop.setOnClickListener(v -> stopClicking());
        btnRecord.setOnClickListener(v -> startRecording());
        btnStopRecord.setOnClickListener(v -> stopRecording());
        btnSaveConfig.setOnClickListener(v -> saveCurrentConfig());
        btnLoadConfig.setOnClickListener(v -> loadSelectedConfig());
        btnDeleteConfig.setOnClickListener(v -> deleteSelectedConfig());

        updateButtons();
    }

    // ==================== 任务管理 ====================

    /** 将当前输入添加为任务 */
    private void addCurrentTask() {
        int mode = rgMode.getCheckedRadioButtonId();
        String desc = "";

        if (mode == R.id.rbCoordinate) {
            String xStr = edtX.getText().toString().trim();
            String yStr = edtY.getText().toString().trim();
            if (xStr.isEmpty() || yStr.isEmpty()) {
                Toast.makeText(this, "请输入坐标", Toast.LENGTH_SHORT).show();
                return;
            }
            int x = Integer.parseInt(xStr);
            int y = Integer.parseInt(yStr);
            userTasks.add(new ClickTask(ClickTask.TYPE_CLICK, x + "," + y));
            desc = "👆 点击(" + x + "," + y + ")";

        } else if (mode == R.id.rbText) {
            String text = edtText.getText().toString().trim();
            if (text.isEmpty()) {
                Toast.makeText(this, "请输入控件文本", Toast.LENGTH_SHORT).show();
                return;
            }
            userTasks.add(new ClickTask(ClickTask.TYPE_TEXT, text));
            desc = "🔤 文本: " + text;

        } else if (mode == R.id.rbResourceId) {
            String resId = edtText.getText().toString().trim();
            if (resId.isEmpty()) {
                Toast.makeText(this, "请输入 resourceId", Toast.LENGTH_SHORT).show();
                return;
            }
            userTasks.add(new ClickTask(ClickTask.TYPE_ID, resId));
            desc = "🆔 ID: " + resId;

        } else if (mode == R.id.rbLongPress) {
            String xStr = edtX.getText().toString().trim();
            String yStr = edtY.getText().toString().trim();
            String durStr = edtLongPressDuration.getText().toString().trim();
            if (xStr.isEmpty() || yStr.isEmpty()) {
                Toast.makeText(this, "请输入坐标", Toast.LENGTH_SHORT).show();
                return;
            }
            int duration = durStr.isEmpty() ? 2000 : Integer.parseInt(durStr);
            int x = Integer.parseInt(xStr);
            int y = Integer.parseInt(yStr);
            userTasks.add(new ClickTask(ClickTask.TYPE_LONG_PRESS, x + "," + y + "," + duration));
            desc = "👆长按(" + x + "," + y + "," + duration + "ms)";

        } else if (mode == R.id.rbSwipe) {
            String x1 = edtSwipeX1.getText().toString().trim();
            String y1 = edtSwipeY1.getText().toString().trim();
            String x2 = edtSwipeX2.getText().toString().trim();
            String y2 = edtSwipeY2.getText().toString().trim();
            String dur = edtSwipeDuration.getText().toString().trim();
            if (x1.isEmpty() || y1.isEmpty() || x2.isEmpty() || y2.isEmpty()) {
                Toast.makeText(this, "请输入滑动起止坐标", Toast.LENGTH_SHORT).show();
                return;
            }
            int duration = dur.isEmpty() ? 300 : Integer.parseInt(dur);
            userTasks.add(new ClickTask(ClickTask.TYPE_SWIPE,
                    x1 + "," + y1 + "," + x2 + "," + y2 + "," + duration));
            desc = "↔ 滑动(" + x1 + "," + y1 + "→" + x2 + "," + y2 + ")";
        }

        taskDisplayList.add(desc);
        taskAdapter.notifyDataSetChanged();
        Toast.makeText(this, "已添加: " + desc, Toast.LENGTH_SHORT).show();
    }

    // ==================== 启动 & 停止 ====================

    private void startClicking() {
        if (!ClickAccessibilityService.isServiceAvailable()) {
            Toast.makeText(this, "请先开启无障碍服务", Toast.LENGTH_SHORT).show();
            return;
        }
        if (userTasks.isEmpty()) {
            Toast.makeText(this, "请至少添加一个任务", Toast.LENGTH_SHORT).show();
            return;
        }

        ClickAccessibilityService service = ClickAccessibilityService.instance;
        service.clearTasks();
        service.tasks = new java.util.ArrayList<>(userTasks);

        // 读取配置
        int interval = parseInt(edtInterval, 1000);
        int randomDelay = parseInt(edtRandomDelay, 0);
        int loopCount = parseInt(edtLoopCount, -1);
        String waitText = edtWaitText.getText().toString().trim();
        String stopText = edtStopText.getText().toString().trim();

        service.setInterval(interval);
        service.setRandomDelay(randomDelay);
        service.setLoopCount(loopCount);
        if (!waitText.isEmpty()) service.setWaitText(waitText);
        if (!stopText.isEmpty()) service.setStopText(stopText);

        // 图片定位
        String imgPath = edtImageMatchPath.getText().toString().trim();
        if (!imgPath.isEmpty()) {
            int offX = parseInt(edtImageOffsetX, 0);
            int offY = parseInt(edtImageOffsetY, 0);
            service.setImageMatch(imgPath, offX, offY);
        }

        service.startClicking();
        updateButtons();
        floatingController.updateStatus("▶ 运行中");
        Toast.makeText(this, "已开始 (" + userTasks.size() + " 个任务)", Toast.LENGTH_SHORT).show();
    }

    private void stopClicking() {
        if (ClickAccessibilityService.isServiceAvailable()) {
            ClickAccessibilityService.instance.stopClicking();
            updateButtons();
            floatingController.updateStatus("⏸ 就绪");
            Toast.makeText(this, "已停止", Toast.LENGTH_SHORT).show();
        }
    }

    // ==================== 录制 & 回放 ====================

    private void startRecording() {
        if (!ClickAccessibilityService.isServiceAvailable()) {
            Toast.makeText(this, "请先开启无障碍服务", Toast.LENGTH_SHORT).show();
            return;
        }

        // 生成录制文件路径
        String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());
        File dir = new File(getExternalFilesDir(null), "recordings");
        if (!dir.exists()) dir.mkdirs();
        currentRecordPath = new File(dir, "record_" + timestamp + ".json").getAbsolutePath();

        ClickAccessibilityService service = ClickAccessibilityService.instance;
        service.startRecording(currentRecordPath);
        recording = true;

        btnRecord.setEnabled(false);
        btnStopRecord.setEnabled(true);
        Toast.makeText(this, "🔴 录制中... 操作后点击停止", Toast.LENGTH_LONG).show();
    }

    private void stopRecording() {
        if (ClickAccessibilityService.isServiceAvailable()) {
            ClickAccessibilityService.instance.stopRecording();
            recording = false;
            btnRecord.setEnabled(true);
            btnStopRecord.setEnabled(false);
            Toast.makeText(this, "✅ 录制已保存: " + currentRecordPath, Toast.LENGTH_LONG).show();

            // 加载录制的任务到列表
            ClickAccessibilityService service = ClickAccessibilityService.instance;
            service.loadAndReplay(currentRecordPath);
            userTasks = new java.util.ArrayList<>(service.tasks);
            taskDisplayList.clear();
            for (ClickTask t : userTasks) {
                taskDisplayList.add(taskToString(t));
            }
            taskAdapter.notifyDataSetChanged();
        }
    }

    private String taskToString(ClickTask t) {
        switch (t.type) {
            case ClickTask.TYPE_CLICK: return "👆 点击(" + t.value + ")";
            case ClickTask.TYPE_TEXT: return "🔤 文本(" + t.value + ")";
            case ClickTask.TYPE_ID: return "🆔 ID(" + t.value + ")";
            case ClickTask.TYPE_LONG_PRESS: return "👆长按(" + t.value + ")";
            case ClickTask.TYPE_SWIPE: return "↔ 滑动(" + t.value + ")";
            case ClickTask.TYPE_IMAGE: return "🖼 图片(" + t.value + ")";
            default: return "未知任务";
        }
    }

    // ==================== 配置管理 ====================

    private void saveCurrentConfig() {
        String name = "配置_" + new SimpleDateFormat("MMdd_HHmm", Locale.getDefault()).format(new Date());
        ConfigManager.Config config = new ConfigManager.Config();

        // 读取当前界面值
        int mode = rgMode.getCheckedRadioButtonId();
        if (mode == R.id.rbCoordinate) config.mode = 0;
        else if (mode == R.id.rbText) config.mode = 1;
        else config.mode = 2;

        config.x = parseInt(edtX, 0);
        config.y = parseInt(edtY, 0);
        config.text = edtText.getText().toString().trim();
        config.interval = parseInt(edtInterval, 1000);
        config.randomDelay = parseInt(edtRandomDelay, 0);
        config.loopCount = parseInt(edtLoopCount, -1);
        config.waitText = edtWaitText.getText().toString().trim();
        config.stopText = edtStopText.getText().toString().trim();

        configManager.saveConfig(name, config);
        loadSavedConfigs();
        Toast.makeText(this, "已保存: " + name, Toast.LENGTH_SHORT).show();
    }

    private void loadSelectedConfig() {
        String name = (String) spSavedConfig.getSelectedItem();
        if (name == null || name.isEmpty()) {
            Toast.makeText(this, "请先选择一个配置", Toast.LENGTH_SHORT).show();
            return;
        }
        ConfigManager.Config config = configManager.loadConfig(name);
        if (config == null) return;

        // 应用配置到界面
        switch (config.mode) {
            case 0: rgMode.check(R.id.rbCoordinate); break;
            case 1: rgMode.check(R.id.rbText); break;
            case 2: rgMode.check(R.id.rbResourceId); break;
        }
        edtX.setText(String.valueOf(config.x));
        edtY.setText(String.valueOf(config.y));
        edtText.setText(config.text);
        edtInterval.setText(String.valueOf(config.interval));
        edtRandomDelay.setText(String.valueOf(config.randomDelay));
        edtLoopCount.setText(config.loopCount == -1 ? "" : String.valueOf(config.loopCount));
        edtWaitText.setText(config.waitText);
        edtStopText.setText(config.stopText);

        Toast.makeText(this, "已加载: " + name, Toast.LENGTH_SHORT).show();
    }

    private void deleteSelectedConfig() {
        String name = (String) spSavedConfig.getSelectedItem();
        if (name == null || name.isEmpty()) return;
        configManager.deleteConfig(name);
        loadSavedConfigs();
        Toast.makeText(this, "已删除: " + name, Toast.LENGTH_SHORT).show();
    }

    private void loadSavedConfigs() {
        List<String> configs = configManager.getConfigList();
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, configs);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spSavedConfig.setAdapter(adapter);
    }

    // ==================== FloatingController 回调 ====================

    @Override
    public void onStart() { startClicking(); }
    @Override
    public void onStop() { stopClicking(); }

    @Override
    public void onRecord() {
        if (recording) {
            stopRecording();
        } else {
            startRecording();
        }
    }

    @Override
    public void onReplay() {
        if (userTasks.isEmpty() && currentRecordPath != null) {
            ClickAccessibilityService service = ClickAccessibilityService.instance;
            service.loadAndReplay(currentRecordPath);
            userTasks = new java.util.ArrayList<>(service.tasks);
            taskDisplayList.clear();
            for (ClickTask t : userTasks) {
                taskDisplayList.add(taskToString(t));
            }
            taskAdapter.notifyDataSetChanged();
        }
        startClicking();
    }

    // ==================== 辅助方法 ====================

    private int parseInt(EditText edt, int def) {
        try {
            String s = edt.getText().toString().trim();
            return s.isEmpty() ? def : Integer.parseInt(s);
        } catch (NumberFormatException e) { return def; }
    }

    private void updateButtons() {
        boolean running = ClickAccessibilityService.isRunning();
        btnStart.setEnabled(!running);
        btnStop.setEnabled(running);
        btnAddTask.setEnabled(!running);
        btnSaveConfig.setEnabled(!running);
        btnRecord.setEnabled(!running);
        btnStopRecord.setEnabled(running && recording);
    }
}
