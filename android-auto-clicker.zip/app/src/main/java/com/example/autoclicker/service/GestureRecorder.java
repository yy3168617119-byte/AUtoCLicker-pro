package com.example.autoclicker.service;

import android.os.Environment;
import android.util.Log;

import com.example.autoclicker.service.ClickAccessibilityService.ClickTask;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * 手势录制 & 回放引擎
 * 
 * 功能：
 * - 录制：记录每次点击/滑动/长按操作及时间间隔
 * - 保存：JSON 格式存储到文件
 * - 加载：从文件读取并转换为 ClickTask 列表
 */
public class GestureRecorder {

    private static final String TAG = "GestureRecorder";

    private boolean recording = false;
    private String savePath = null;
    private FileWriter writer = null;
    private long lastTimestamp = 0;
    private List<GestureEvent> buffer = new ArrayList<>();

    /**
     * 开始录制
     */
    public void startRecording(String path) {
        this.savePath = path;
        this.recording = true;
        this.lastTimestamp = System.currentTimeMillis();
        this.buffer.clear();

        // 确保目录存在
        File dir = new File(path).getParentFile();
        if (dir != null && !dir.exists()) dir.mkdirs();

        try {
            writer = new FileWriter(path, false);
            writer.write("[\n");
        } catch (IOException e) {
            Log.e(TAG, "无法创建录制文件: " + e.getMessage());
        }

        Log.d(TAG, "开始录制 → " + path);
    }

    /**
     * 录制一个任务
     */
    public void recordTask(ClickTask task, boolean success) {
        if (!recording || !success) return;

        long now = System.currentTimeMillis();
        long delay = lastTimestamp > 0 ? now - lastTimestamp : 0;
        lastTimestamp = now;

        GestureEvent event = new GestureEvent(task, delay);
        buffer.add(event);
        Log.d(TAG, "录制: " + event.toString() + ", delay=" + delay + "ms");
    }

    /**
     * 停止录制并保存
     */
    public void stopRecording() {
        recording = false;
        try {
            if (writer != null) {
                // 写入 JSON 数组
                for (int i = 0; i < buffer.size(); i++) {
                    writer.write("  " + buffer.get(i).toJson());
                    if (i < buffer.size() - 1) writer.write(",");
                    writer.write("\n");
                }
                writer.write("]");
                writer.flush();
                writer.close();
            }
            Log.d(TAG, "录制完成，共 " + buffer.size() + " 个事件");
        } catch (IOException e) {
            Log.e(TAG, "保存失败: " + e.getMessage());
        }
    }

    /**
     * 从文件加载录制事件
     */
    public List<GestureEvent> loadEvents(String path) {
        List<GestureEvent> events = new ArrayList<>();
        File file = new File(path);
        if (!file.exists()) {
            Log.e(TAG, "文件不存在: " + path);
            return null;
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line);
            }

            String json = sb.toString().trim();
            if (json.startsWith("[")) json = json.substring(1);
            if (json.endsWith("]")) json = json.substring(0, json.length() - 1);

            String[] items = json.split("\\},");
            for (String item : items) {
                if (!item.trim().startsWith("{")) item = "{" + item;
                if (!item.trim().endsWith("}")) item = item + "}";
                GestureEvent event = GestureEvent.fromJson(item.trim());
                if (event != null) events.add(event);
            }

            Log.d(TAG, "加载 " + events.size() + " 个事件 from " + path);
        } catch (IOException e) {
            Log.e(TAG, "加载失败: " + e.getMessage());
            return null;
        }

        return events;
    }

    /**
     * 获取录制事件列表
     */
    public List<GestureEvent> getBuffer() {
        return buffer;
    }

    /**
     * 手势事件内部类
     */
    public static class GestureEvent {
        public ClickTask task;
        public long delayMs;

        public GestureEvent(ClickTask task, long delayMs) {
            this.task = task;
            this.delayMs = delayMs;
        }

        public String toJson() {
            return String.format(
                "{\"delay\":%d,\"type\":%d,\"value\":\"%s\"}",
                delayMs, task.type, task.value
            );
        }

        public static GestureEvent fromJson(String json) {
            try {
                // 解析 delay
                int dIdx = json.indexOf("\"delay\":");
                int dStart = dIdx + 8;
                int dEnd = json.indexOf(",", dStart);
                long delay = Long.parseLong(json.substring(dStart, dEnd));

                // 解析 type
                int tIdx = json.indexOf("\"type\":");
                int tStart = tIdx + 7;
                int tEnd = json.indexOf(",", tStart);
                int type = Integer.parseInt(json.substring(tStart, tEnd));

                // 解析 value
                int vStart = json.indexOf("\"value\":\"") + 9;
                int vEnd = json.indexOf("\"", vStart);
                String value = json.substring(vStart, vEnd);

                return new GestureEvent(new ClickTask(type, value), delay);
            } catch (Exception e) {
                return null;
            }
        }

        public ClickTask toClickTask() {
            ClickTask t = new ClickTask(task.type, task.value);
            return t;
        }

        @Override
        public String toString() {
            String typeStr;
            switch (task.type) {
                case 0: typeStr = "点击(" + task.value + ")"; break;
                case 1: typeStr = "文本(" + task.value + ")"; break;
                case 2: typeStr = "ID(" + task.value + ")"; break;
                case 3: typeStr = "长按(" + task.value + ")"; break;
                case 4: typeStr = "滑动(" + task.value + ")"; break;
                case 5: typeStr = "图片(" + task.value + ")"; break;
                default: typeStr = "未知";
            }
            return typeStr;
        }
    }
}
